import "./App.css";

const Ui = (props) => {
  return (
    <div className="wrapper">
      <input
        className="touchable color-picker"
        type="color"
        id="colorpicker"
        value={props.color}
        onChange={(e) => props.setColor(e)}
      />
    </div>
  );
};

export default Ui;
