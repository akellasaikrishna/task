import "./App.css";
import * as THREE from "three";
import { useEffect, useState } from "react";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import Ui from "./ui";

function App() {
  const [currColor, setCurrColor] = useState("#441556");

  let scene, camera, controls;
  let renderer = new THREE.WebGLRenderer({ antialias: true });
  scene = new THREE.Scene();
  scene.background = new THREE.Color(currColor);
  camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.render(scene, camera);
  camera.position.z = 30;
  let geometry = new THREE.SphereGeometry(10, 10, 10);
  let wireframe = new THREE.WireframeGeometry(geometry);
  let line = new THREE.LineSegments(wireframe);
  line.material.depthTest = false;
  line.material.opacity = 0.25;
  line.material.transparent = true;
  scene.add(line);
  controls = new OrbitControls(camera, renderer.domElement);

  const animate = () => {
    requestAnimationFrame(animate);
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.render(scene, camera);
    controls.update();
  };

  useEffect(() => {
    document.body
      .getElementsByClassName("ThreeLayer")[0]
      .appendChild(renderer.domElement);
    animate();
  });

  const appendColor = (e) => {
    while (scene.children.length > 0) {
      scene.remove(scene.children[0]);
    }
    console.log(scene.children[0]);
    setCurrColor(e.target.value);
    scene = new THREE.Scene();
    scene.background = new THREE.Color(e.target.value);
    scene.add(line);
    renderer.render(scene, camera);
  };

  return (
    <div className="App">
      <div className="ThreeLayer"></div>
      <Ui setColor={appendColor} color={currColor} />
    </div>
  );
}

export default App;
